# FruitShooter2

Frank Bonini, Aaron Yu, Dan Lee, Josh Levis


This is our final project for CIS 111B, Summer of 2017. We have created a shooter-style 2D videogame, utilizing 
the slick2d gaming API.

To run the game, run the "RunGame" class.

Include all of the libraries found in the "libraries" folder.

For your native library location, it should be "libraries/lwjgl-2.9.3/native/windows"


DISCLAIMER:
Everything distributed in this package is used for EDUCATIONAL PURPOSES ONLY

MUSIC:
Royalty free, sourced from http://freemusicarchive.org/music/Visager/Songs_From_An_Unmade_World_2/


For Project:
UML:
	The UML diagram is in the root folder and is saved as a .gif image
JavaDoc:
	The JavaDoc for this project can be found in the "doc" folder.
Runnable Jar:
	The runnable .jar file can be found in the "release folder". To run it, run the included .bat file.