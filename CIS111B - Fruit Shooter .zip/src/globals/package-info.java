/**
 * This is a package for global variables.
 */
/**
 * @author Frank
 *
 */
package globals;