/**
 * This is a package for utility classes like debugging and file writing.
 */
/**
 * @author Frank
 *
 */
package utilities;