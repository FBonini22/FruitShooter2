/**
 * All music and audio effect-related code goes in this package.
 */
/**
 * @author Frank
 *
 */
package sounds;
