/**
 * This is a package for all of the entities. Every entity class should extend Entity, which already extends
 * Hitbox.
 */
/**
 * @author Frank
 *
 */
package entities;