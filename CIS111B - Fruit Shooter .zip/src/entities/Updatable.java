package entities;

public abstract class Updatable {

	
	
}
