package entities;

//Still a lot more to add. Still working on it.
public enum EnemyMovement {
	Random,
	SliceToRight,
	SliceToLeft,
	VShoot,
	Spider,
	Teleport,
	RightUnderSwing,
	LeftUnderSwing,
	RightChase,
	LeftChase,
	Star,
	Parabola,
	
	
	
	

}
