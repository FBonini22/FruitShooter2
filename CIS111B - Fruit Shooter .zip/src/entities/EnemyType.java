package entities;

public enum EnemyType {
	Squirrel,
	JumboSquirrel_1,
	JumboSquirrel_2

}
