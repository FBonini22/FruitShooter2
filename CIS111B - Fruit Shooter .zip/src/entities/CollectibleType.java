package entities;

//The list in engine.CollectibleSpawner depends on the order of the items in this enumerator. DO NOT CHANGE UNTIL HAVING REVIEWED
//THE AFOREMENTIONED LIST

public enum CollectibleType {
	Health,
	PowerUp,
	Points,
	Bomb
}
