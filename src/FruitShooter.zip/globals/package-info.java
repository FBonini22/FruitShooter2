/**
 * 
 */
/**
 * @author Frank
 *
 */
package globals;