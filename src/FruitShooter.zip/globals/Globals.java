package globals;

public class Globals {

	public static boolean DEBUGGING = true;			//Change this variable to true for debugging mode.
}
