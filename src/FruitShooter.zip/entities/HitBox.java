package entities;

public abstract class HitBox {

	//Constants
	
	
	//Instance Variables
	//TO-DO change accessibility
	protected float x;
	protected float y;
	protected float width;
	protected float height;
	
	public HitBox(){
		
	}
	
}
