package entities;

public class Fruit {

}
